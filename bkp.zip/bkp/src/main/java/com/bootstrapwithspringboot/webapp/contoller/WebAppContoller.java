package com.bootstrapwithspringboot.webapp.contoller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bootstrapwithspringboot.webapp.model.Customer;
 


@Controller
public class WebAppContoller 
{
	
	
	    private static final String EXTERNAL_FILE_PATH="/Users/jasiellp/Documents/ReciboDEFIS-295998112018001.pdf";
	    
    private String appMode;

    List<Customer> lstCustomers = new ArrayList<Customer>();
	
	@PostConstruct
    public void init() throws Exception 
	{
		lstCustomers.add(new Customer(  "Data Server", "Online" ));
		lstCustomers.add(new Customer(  "Arquivaria", "Online" ));
		lstCustomers.add(new Customer("Message", "Off-line" ));
    }
    
    
    @Autowired
    public WebAppContoller(Environment environment)
    {
        appMode = environment.getProperty("app-mode");
    }

    @RequestMapping("/")
    public String index(Model model)
    { 	
    	model.addAttribute("datetime", new Date());
        model.addAttribute("username", "Calypso");
        model.addAttribute("projectname", "WebApp");
        model.addAttribute("mode", appMode);

        return "index";
    }
    
    @RequestMapping("/home")
    public String home(Model model)
    { 	
    	model.addAttribute("datetime", new Date());
        model.addAttribute("username", "Calypso");
        model.addAttribute("projectname", "WebApp");
        model.addAttribute("mode", appMode);

        return "index";
    }
     
    
    @RequestMapping("/status-calypso")
    public String defectDetails(Model model) 
    {
    	 model.addAttribute("customers", lstCustomers);
        return "index2";
    }
    
    private static final String FILE_PATH = EXTERNAL_FILE_PATH;
 
    // Using ResponseEntity<InputStreamResource>
    @GetMapping("/download1")
    public ResponseEntity<InputStreamResource> downloadFile1() throws IOException {

       File file = new File(FILE_PATH);
       InputStreamResource resource = new InputStreamResource(new FileInputStream(file));

       return ResponseEntity.ok()
             .header(HttpHeaders.CONTENT_DISPOSITION,
                   "attachment;filename=" + file.getName())
             .contentType(MediaType.APPLICATION_PDF).contentLength(file.length())
             .body(resource);
    }
     
     
}
