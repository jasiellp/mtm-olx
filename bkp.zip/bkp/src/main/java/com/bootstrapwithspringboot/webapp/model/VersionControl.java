package com.bootstrapwithspringboot.webapp.model;

public class VersionControl
{
	 
	private String name;
	private String status; 
	
	public VersionControl()
	{
		
	}
	
	public VersionControl( String Engine, String  status )
	{
	 
		this.name = Engine;
		this.status = status; 
	}
  
	
	public String getName() 
	{
		return name;
	}
 
	public void setName(String name) 
	{
		this.name = name;
	}
 
	public String getStatus() 
	{
		return status;
	}
 
	public void setStatus(String age) 
	{
		this.status = age;
	}
  
 
	@Override
	public String toString() 
	{
		return "Customer {Engine:" + name + ", Status:" + status + " }";
	}

}